#include <iostream>
#include <limits>
using namespace std;

// Terminal Color Codes
#define GREEN "\033[1;32m"
#define RED "\033[1;31m"
#define YELLOW "\033[1;33m"
#define RESET "\033[0m"

// Base class
class TrafficLane {
private:
    string name;
    int vehicleCount;
    bool hasAmbulance;

public:
    TrafficLane(string n) {
        name = n;
        vehicleCount = 0;
        hasAmbulance = false;
    }

    // Getters
    string getName() const { return name; }
    int getVehicleCount() const { return vehicleCount; }
    bool getHasAmbulance() const { return hasAmbulance; }

    // Setters
    void setName(string n) { name = n; }
    void setVehicleCount(int count) { vehicleCount = count; }
    void setHasAmbulance(bool amb) { hasAmbulance = amb; }

    // Virtual input
    virtual void inputData() {
        while (true) {
            cout << YELLOW << "Enter number of vehicles in " << name << ": " << RESET;
            cin >> vehicleCount;
            if (cin.fail() || vehicleCount < 0) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << RED << "Invalid input. Please enter a non-negative integer.\n" << RESET;
            } else break;
        }

        char ambu;
        cout << "Is there an ambulance in " << name << "? (y/n): ";
        cin >> ambu;
        hasAmbulance = (ambu == 'y' || ambu == 'Y');
    }

    virtual ~TrafficLane() {}
};

// Emergency Lane
class EmergencyLane : public TrafficLane {
public:
    EmergencyLane(string n) : TrafficLane(n) {}

    void inputData() override {
        TrafficLane::inputData();
    }
};

// VIP Lane
class VIPLane : public TrafficLane {
public:
    VIPLane(string n) : TrafficLane(n) {}

    void inputData() override {
        TrafficLane::inputData();
    }
};

// Controller
class TrafficController : public TrafficLane {
public:
    EmergencyLane north;
    TrafficLane south;
    VIPLane east;
    TrafficLane west;

    TrafficController()
        : TrafficLane(""), north("North"), south("South"), east("East"), west("West") {}

    void collectData() {
        cout << "\n--- Traffic Data Collection ---\n";
        north.inputData();
        south.inputData();
        east.inputData();
        west.inputData();
    }

    void controlSignal() {
        cout << "\n--- Signal Control Decision ---\n";
        TrafficLane* greenLane = &north;
        string reason;

        if (north.getHasAmbulance()) {
            greenLane = &north;
            reason = "Ambulance present in North lane";
        }
        else if (south.getHasAmbulance()) {
            greenLane = &south;
            reason = "Ambulance present in South lane";
        }
        else if (east.getHasAmbulance()) {
            greenLane = &east;
            reason = "Ambulance present in East lane";
        }
        else if (west.getHasAmbulance()) {
            greenLane = &west;
            reason = "Ambulance present in West lane";
        }
        else {
            if (south.getVehicleCount() > greenLane->getVehicleCount()) greenLane = &south;
            if (east.getVehicleCount() > greenLane->getVehicleCount()) greenLane = &east;
            if (west.getVehicleCount() > greenLane->getVehicleCount()) greenLane = &west;

            reason = "Highest vehicle count in " + greenLane->getName() + " lane";
        }

        cout << GREEN << "? Green Signal Given to " << greenLane->getName() << " Lane\n" << RESET;
        cout << "?? Reason: " << reason << "\n";

        int timeGreen = greenLane->getVehicleCount() * 2;
        if (greenLane->getHasAmbulance()) timeGreen += 5;

        cout << YELLOW << "?? Signal time: " << timeGreen << " seconds (simulated)\n" << RESET;
        cout << RED << "? Red Signal for " << greenLane->getName() << " Lane\n" << RESET;
    }
};

int main() {
    TrafficController controller;
    char runAgain;

    cout << GREEN<< "?? Smart Traffic Management Simulation Started ??\n" << RESET;

    do {
        controller.collectData();
        controller.controlSignal();

        cout << "\nDo you want to run another cycle? (y/n): ";
        cin >> runAgain;
    } while (runAgain == 'y' || runAgain == 'Y');

    cout << "\n? Simulation ended. Stay safe on the road!\n";
    return 0;
}

